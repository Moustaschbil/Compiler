bool t = true

void main() {
	if (t){
		t = false;
	}
}
