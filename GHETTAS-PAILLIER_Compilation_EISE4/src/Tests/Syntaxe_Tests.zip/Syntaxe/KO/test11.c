void main() {
	int f = true;
	if (f == true)(){
		f = 2;
	}
}
