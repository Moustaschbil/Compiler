void main() {
	[]
	int a = 4;
	a = a - 5;
}
