void main() {
	int a = 3;
	int b = 0;
	while(true) {
		b = b + a;
	}}
}
