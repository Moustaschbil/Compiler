void main() {{
	int x = 10;
	do
	{
		x = x - 1;
	} while ( x > 0 );
}
