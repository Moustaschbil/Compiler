void main(){
	//ceci est un commentaire de test
	print("OUI\n")
}
