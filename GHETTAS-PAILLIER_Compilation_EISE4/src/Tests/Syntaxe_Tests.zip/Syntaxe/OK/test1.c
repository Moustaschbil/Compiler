int a = 0;
int b = 0;

void main(){
	int a = 1;
	int c = 2;

	if (true) {
		int a = 5;
		int d = 6;
		a = a + b + c + d;
	}
	else {
		int d;
		int e;
		e = d = 1;
	}
}
