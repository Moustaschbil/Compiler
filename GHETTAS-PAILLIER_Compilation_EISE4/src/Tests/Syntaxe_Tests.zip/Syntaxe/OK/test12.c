int main() {
	int a = 2;
	int b = 1;
	b = a - b;
}
