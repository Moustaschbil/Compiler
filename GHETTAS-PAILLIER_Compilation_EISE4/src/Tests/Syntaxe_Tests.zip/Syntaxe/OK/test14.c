int f(int x){
	x = x + 3;
	return x;
}

void main() {
	int a = 4;
	a = f(a);
}
