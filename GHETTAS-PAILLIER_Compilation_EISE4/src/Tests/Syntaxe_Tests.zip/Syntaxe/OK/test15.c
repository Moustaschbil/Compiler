bool v(int x) {
	return false;
}

void main() {
	bool a = v(5);
}
