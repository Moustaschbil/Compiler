int main() {
	int r = 2;
}
