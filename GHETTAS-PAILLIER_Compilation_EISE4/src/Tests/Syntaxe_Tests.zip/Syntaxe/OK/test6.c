void main() {
	bool b = 2;
	int c = 3;
	b = b * c;
}
