void main(){
	int i;
	int b
	for(i = 0; i < 100; i = i + 1){
		b = i / 1;
	}
}
