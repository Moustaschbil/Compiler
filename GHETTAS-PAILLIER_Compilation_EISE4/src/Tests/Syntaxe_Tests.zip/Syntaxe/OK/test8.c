int main() {
	int c = 2;
	c = c / 0;
}
